//
//  SKUIOfferView.m
//  JYLoginTest
//
//  Created by wangjiale on 2018/1/30.
//  Copyright © 2018年 Joy. All rights reserved.
//

#import "SKUIOfferView.h"

@implementation SKUIOfferView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
