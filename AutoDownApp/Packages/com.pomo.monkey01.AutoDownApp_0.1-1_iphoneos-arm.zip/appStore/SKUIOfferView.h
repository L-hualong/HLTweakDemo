//
//  SKUIOfferView.h
//  JYLoginTest
//
//  Created by wangjiale on 2018/1/30.
//  Copyright © 2018年 Joy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SKUIOfferView : UIView
- (void)_buttonAction:(id)arg1;
@end
