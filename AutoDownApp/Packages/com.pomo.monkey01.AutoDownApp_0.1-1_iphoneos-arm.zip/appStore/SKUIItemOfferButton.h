//
//  SKUIItemOfferButton.h
//  AutoDownApp
//
//  Created by 刘华龙 on 2018/9/7.
//

#import <UIKit/UIKit.h>

@interface SKUIItemOfferButton : UIButton
@property(readonly, nonatomic) NSString *title;
@end
