//
//  SKUISearchFieldController.h
//  JYLoginTest
//
//  Created by wangjiale on 2018/1/25.
//  Copyright © 2018年 Joy. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SKUISearchFieldController : NSObject
- (void)_reloadData;
@property(readonly, nonatomic) UISearchBar *searchBar;
- (void)searchBarSearchButtonClicked:(id)arg1;
@end
