//
//  SKUIAccountButtonsViewController.h
//  JYLoginTest
//
//  Created by wangjiale on 2018/2/7.
//  Copyright © 2018年 Joy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SKUIAccountButtonsViewController : UIViewController
- (void)_signOut;
@end
