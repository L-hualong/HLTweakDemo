//
//  SKUIStorePageSectionsViewController.h
//  JYLoginTest
//
//  Created by wangjiale on 2018/1/29.
//  Copyright © 2018年 Joy. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SKUIStorePageSectionsViewController : UIViewController
@property(readonly, nonatomic) UICollectionView *collectionView;
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath;
-(void)findAllSubviews:(UIView *)view;
@end

